var searchData=
[
  ['trackalbum',['trackAlbum',['../classvs1053.html#a2f4ef12d9bdf24936b26cee6349ffb7f',1,'vs1053']]],
  ['trackartist',['trackArtist',['../classvs1053.html#af71732e201c5b514dbc11c46f3f41be8',1,'vs1053']]],
  ['tracktitle',['trackTitle',['../classvs1053.html#adc5f512354b4c151eaaee12a3da2db82',1,'vs1053']]]
];
