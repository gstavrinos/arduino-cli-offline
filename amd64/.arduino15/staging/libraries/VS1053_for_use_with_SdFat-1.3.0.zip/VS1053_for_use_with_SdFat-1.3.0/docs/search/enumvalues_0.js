var searchData=
[
  ['both',['both',['../vs1053___sd_fat_8h.html#ad701087b7fa2b683f9da6cdb04c9ecbfad0957f04342d48a36bfb6beefd2b04f1',1,'vs1053_SdFat.h']]]
];
