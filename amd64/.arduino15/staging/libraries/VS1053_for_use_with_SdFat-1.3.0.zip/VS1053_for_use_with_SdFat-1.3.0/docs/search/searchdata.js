var indexSectionsWithContent =
{
  0: "abcdefgilmnprstuvw",
  1: "stv",
  2: "v",
  3: "abcdefgimprstv",
  4: "bmnpstvw",
  5: "fs",
  6: "bdilnprtu",
  7: "bfgmpstuv",
  8: "adt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros",
  8: "Pages"
};

