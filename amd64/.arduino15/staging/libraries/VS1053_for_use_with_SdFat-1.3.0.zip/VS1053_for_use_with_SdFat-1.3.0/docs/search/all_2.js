var searchData=
[
  ['cs_5fhigh',['cs_high',['../classvs1053.html#a76dc4bef02b6f7a52dcf03f983836f21',1,'vs1053']]],
  ['cs_5flow',['cs_low',['../classvs1053.html#a23bb836013a2bef833f9f8944135d3d7',1,'vs1053']]],
  ['currentposition',['currentPosition',['../classvs1053.html#a9023c246d50107db0042d486b995f30e',1,'vs1053']]]
];
