var searchData=
[
  ['baretouch',['BARETOUCH',['../vs1053___sd_fat__config_8h.html#a5649127c062be5324d8ed4a3b7fa2617',1,'vs1053_SdFat_config.h']]]
];
