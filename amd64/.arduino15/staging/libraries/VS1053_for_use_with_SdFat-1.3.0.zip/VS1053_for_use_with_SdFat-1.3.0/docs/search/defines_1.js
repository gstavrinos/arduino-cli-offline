var searchData=
[
  ['false',['FALSE',['../vs1053___sd_fat_8h.html#aa93f0eb578d23995850d61f7d61c55c1',1,'vs1053_SdFat.h']]]
];
