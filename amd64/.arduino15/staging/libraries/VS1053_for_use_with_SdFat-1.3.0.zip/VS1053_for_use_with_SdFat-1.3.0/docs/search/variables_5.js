var searchData=
[
  ['track',['track',['../classvs1053.html#a51e790a8db7a2ab9f2d557b22e986dff',1,'vs1053']]],
  ['treble_5famplitude',['Treble_Amplitude',['../unionvs1053_1_1sci__bass__m.html#a0db4c18af654178d22502587d4c47635',1,'vs1053::sci_bass_m']]],
  ['treble_5ffreqlimt',['Treble_Freqlimt',['../unionvs1053_1_1sci__bass__m.html#af0cf458b5e3c6fb6c3f4153d7fe3ad77',1,'vs1053::sci_bass_m']]]
];
