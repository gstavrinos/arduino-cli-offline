var searchData=
[
  ['ready',['ready',['../vs1053___sd_fat_8h.html#a1e43f52ed18e725e71477e654c74de73a620a31d3a677faaa9e000fb23967a473',1,'vs1053_SdFat.h']]],
  ['refill',['refill',['../classvs1053.html#ac02364a767179f40d3be440a82115994',1,'vs1053']]],
  ['resumedatastream',['resumeDataStream',['../classvs1053.html#a1165fc83b2297dd678750ec95188fd0c',1,'vs1053']]],
  ['resumemusic',['resumeMusic',['../classvs1053.html#ae0a58d7ff526b0788af1ef649bc0dcf0',1,'vs1053::resumeMusic()'],['../classvs1053.html#ad32d5fed37e20a7fc4bbcaf7ac57794b',1,'vs1053::resumeMusic(uint32_t)']]]
];
